#include <iostream>
#include "TwoDim.h"
#include "Bfs.h"
#include "InputProcessing.h"

using namespace std;

int main(int argc, char* argv[]) {
    int xGrid, yGrid;
    cin >> xGrid >> yGrid;
    Grid *map = new TwoDim(xGrid, yGrid);
    Bfs currentBfs(map);
    TaxiCenter* station = new TaxiCenter(map, &currentBfs);
    //initializing obstacles
    createObstacles(map);
    while (1) {
        menu(station);
    }
}
